import express from 'express';
import { createServer as createViteServer } from 'vite';
import { createServer } from 'http';
import { Server } from 'socket.io';
import Database from 'better-sqlite3';
import path from 'path';
import { fileURLToPath } from 'url';
import multer from 'multer';
import bcrypt from 'bcryptjs';
import fs from 'fs';

const __dirname = path.dirname(fileURLToPath(import.meta.url));

const uploadsDir = path.join(__dirname, 'uploads');
if (!fs.existsSync(uploadsDir)) {
  fs.mkdirSync(uploadsDir);
}

const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, uploadsDir)
  },
  filename: function (req, file, cb) {
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9)
    cb(null, uniqueSuffix + '-' + file.originalname)
  }
});
const upload = multer({ storage: storage });

const db = new Database('database.sqlite');

// Initialize database schema
db.exec(`
  CREATE TABLE IF NOT EXISTS users (
    id TEXT PRIMARY KEY,
    name TEXT,
    email TEXT UNIQUE,
    password TEXT,
    role_id TEXT,
    last_login TEXT,
    status TEXT
  );

  CREATE TABLE IF NOT EXISTS construction_phases (
    id TEXT PRIMARY KEY,
    title TEXT,
    start_date TEXT,
    end_date TEXT,
    progress_percentage INTEGER,
    budget_allocated REAL,
    budget_spent REAL
  );

  CREATE TABLE IF NOT EXISTS tasks (
    id TEXT PRIMARY KEY,
    phase_id TEXT,
    description TEXT,
    assigned_to TEXT,
    priority TEXT,
    status TEXT,
    due_date TEXT
  );

  CREATE TABLE IF NOT EXISTS daily_logs (
    id TEXT PRIMARY KEY,
    author_id TEXT,
    date TEXT,
    weather_condition TEXT,
    workers_count INTEGER,
    description TEXT,
    media_urls TEXT
  );

  CREATE TABLE IF NOT EXISTS financial_records (
    id TEXT PRIMARY KEY,
    category TEXT,
    amount REAL,
    type_in_out TEXT,
    receipt_url TEXT,
    approval_status TEXT,
    date TEXT,
    description TEXT
  );

  CREATE TABLE IF NOT EXISTS documents (
    id TEXT PRIMARY KEY,
    name TEXT,
    type TEXT,
    size TEXT,
    date TEXT,
    author TEXT,
    version TEXT,
    folder TEXT,
    file_url TEXT
  );
`);

try {
  db.exec('ALTER TABLE financial_records ADD COLUMN description TEXT;');
} catch (e) {
  // Column might already exist
}

// Seed Admin User if not exists
const adminCount = db.prepare('SELECT COUNT(*) as count FROM users WHERE role_id = ?').get('Administrador') as { count: number };
if (adminCount.count === 0) {
  const insertUser = db.prepare('INSERT INTO users (id, name, email, password, role_id, last_login, status) VALUES (?, ?, ?, ?, ?, ?, ?)');
  const hashedPassword = bcrypt.hashSync('admin123', 10);
  insertUser.run('u1', 'Admin Master', 'admin@penedo.com', hashedPassword, 'Administrador', new Date().toISOString(), 'Active');
}

// Seed data if empty
const phasesCount = db.prepare('SELECT COUNT(*) as count FROM construction_phases').get() as { count: number };
if (phasesCount.count === 0) {
  const insertPhase = db.prepare('INSERT INTO construction_phases (id, title, start_date, end_date, progress_percentage, budget_allocated, budget_spent) VALUES (?, ?, ?, ?, ?, ?, ?)');
  insertPhase.run('M1', 'Solo e Sondagem', '2023-01-01', '2023-02-01', 100, 100000, 95000);
  insertPhase.run('M2', 'Muros de Arrimo e Contenção', '2023-02-01', '2023-05-01', 80, 500000, 420000);
  insertPhase.run('M3', 'Radier e Lajes de Transição', '2023-04-01', '2023-06-01', 50, 300000, 150000);
  insertPhase.run('M4', 'Montagem do Esqueleto Metálico (LSF)', '2023-06-01', '2023-08-01', 20, 1200000, 250000);
  insertPhase.run('M5', 'Impermeabilização de Lajes', '2023-08-01', '2023-09-01', 0, 150000, 0);
  insertPhase.run('M6', 'Fechamento Externo (Envelopamento)', '2023-09-01', '2023-10-01', 0, 400000, 0);
  insertPhase.run('M7', 'Instalação das Esquadrias', '2023-10-01', '2023-11-01', 0, 350000, 0);
  insertPhase.run('M8', 'Conclusão da Área Gourmet e Piscina', '2023-11-01', '2023-12-01', 0, 600000, 0);
  insertPhase.run('M9', 'Vistoria Final (Punch List)', '2023-12-01', '2024-01-01', 0, 50000, 0);
  insertPhase.run('M10', 'Inauguração e "Soft Opening"', '2024-01-01', '2024-02-01', 0, 100000, 0);

  const insertTask = db.prepare('INSERT INTO tasks (id, phase_id, description, assigned_to, priority, status, due_date) VALUES (?, ?, ?, ?, ?, ?, ?)');
  insertTask.run('T1', 'M2', 'Concretagem do muro principal', 'Engenheiro_Arquiteto', 'High', 'Fazendo', '2023-04-15');
  insertTask.run('T2', 'M2', 'Drenagem do terreno', 'Empreiteiro_Fornecedor', 'Medium', 'Feito', '2023-03-20');
  insertTask.run('T3', 'M4', 'Recebimento de perfis LSF', 'Engenheiro_Arquiteto', 'High', 'A fazer', '2023-06-05');
  insertTask.run('T4', 'M5', 'Teste de estanqueidade 72h', 'Engenheiro_Arquiteto', 'Critical', 'A fazer', '2023-08-15');
}

async function startServer() {
  const app = express();
  const PORT = 3000;
  const httpServer = createServer(app);
  const io = new Server(httpServer, {
    cors: {
      origin: "*",
      methods: ["GET", "POST"]
    }
  });

  app.use(express.json());
  app.use('/uploads', express.static(uploadsDir));

  // --- Auth Routes ---
  app.post('/api/login', (req, res) => {
    const { email, password } = req.body;
    const user = db.prepare('SELECT * FROM users WHERE email = ?').get(email) as any;
    
    if (user && bcrypt.compareSync(password, user.password)) {
      // Update last login
      db.prepare('UPDATE users SET last_login = ? WHERE id = ?').run(new Date().toISOString(), user.id);
      const { password: _, ...userWithoutPassword } = user;
      res.json({ success: true, user: userWithoutPassword });
    } else {
      res.status(401).json({ success: false, message: 'Email ou senha incorretos' });
    }
  });

  app.get('/api/users', (req, res) => {
    const users = db.prepare('SELECT id, name, email, role_id, last_login, status FROM users').all();
    res.json(users);
  });

  app.post('/api/users', (req, res) => {
    const { name, email, password, role_id } = req.body;
    try {
      const hashedPassword = bcrypt.hashSync(password, 10);
      const id = 'u-' + Date.now();
      const insert = db.prepare('INSERT INTO users (id, name, email, password, role_id, last_login, status) VALUES (?, ?, ?, ?, ?, ?, ?)');
      insert.run(id, name, email, hashedPassword, role_id, new Date().toISOString(), 'Active');
      
      const newUser = db.prepare('SELECT id, name, email, role_id, last_login, status FROM users WHERE id = ?').get(id);
      res.json({ success: true, user: newUser });
    } catch (error: any) {
      res.status(400).json({ success: false, message: error.message });
    }
  });

  // --- API Routes ---
  app.get('/api/phases', (req, res) => {
    const phases = db.prepare('SELECT * FROM construction_phases').all();
    res.json(phases);
  });

  app.post('/api/phases', (req, res) => {
    const { title, start_date, end_date, budget_allocated } = req.body;
    const id = 'M' + Date.now();
    const insert = db.prepare('INSERT INTO construction_phases (id, title, start_date, end_date, progress_percentage, budget_allocated, budget_spent) VALUES (?, ?, ?, ?, ?, ?, ?)');
    insert.run(id, title, start_date, end_date, 0, budget_allocated || 0, 0);
    const newPhase = db.prepare('SELECT * FROM construction_phases WHERE id = ?').get(id);
    res.json(newPhase);
  });

  app.get('/api/tasks', (req, res) => {
    const tasks = db.prepare('SELECT * FROM tasks').all();
    res.json(tasks);
  });

  app.post('/api/tasks', (req, res) => {
    const { id, phase_id, description, assigned_to, priority, status, due_date } = req.body;
    const insert = db.prepare('INSERT INTO tasks (id, phase_id, description, assigned_to, priority, status, due_date) VALUES (?, ?, ?, ?, ?, ?, ?)');
    insert.run(id, phase_id, description, assigned_to, priority, status, due_date);
    const newTask = db.prepare('SELECT * FROM tasks WHERE id = ?').get(id);
    io.emit('task_update', newTask);
    res.json(newTask);
  });

  app.put('/api/tasks/:id', (req, res) => {
    const { status } = req.body;
    const update = db.prepare('UPDATE tasks SET status = ? WHERE id = ?');
    update.run(status, req.params.id);
    const updatedTask = db.prepare('SELECT * FROM tasks WHERE id = ?').get(req.params.id);
    io.emit('task_update', updatedTask);
    res.json(updatedTask);
  });

  app.get('/api/financial', (req, res) => {
    const records = db.prepare('SELECT * FROM financial_records ORDER BY date DESC').all();
    res.json(records);
  });

  app.post('/api/financial', (req, res) => {
    const { category, amount, type_in_out, approval_status, date, description } = req.body;
    const id = 'F-' + Date.now();
    const insert = db.prepare('INSERT INTO financial_records (id, category, amount, type_in_out, receipt_url, approval_status, date, description) VALUES (?, ?, ?, ?, ?, ?, ?, ?)');
    insert.run(id, category || 'Geral', amount, type_in_out, '', approval_status, date, description);
    
    // Update phase budget spent if category matches a phase
    if (category && category.startsWith('M')) {
      db.prepare('UPDATE construction_phases SET budget_spent = budget_spent + ? WHERE id = ?').run(amount, category);
    }
    
    const newRecord = db.prepare('SELECT * FROM financial_records WHERE id = ?').get(id);
    res.json(newRecord);
  });

  app.get('/api/logs', (req, res) => {
    const logs = db.prepare('SELECT * FROM daily_logs ORDER BY date DESC').all();
    res.json(logs);
  });

  app.post('/api/logs', (req, res) => {
    const { author_id, date, weather_condition, workers_count, description, media_urls } = req.body;
    const id = 'L-' + Date.now();
    const insert = db.prepare('INSERT INTO daily_logs (id, author_id, date, weather_condition, workers_count, description, media_urls) VALUES (?, ?, ?, ?, ?, ?, ?)');
    insert.run(id, author_id, date, weather_condition, workers_count, description, media_urls || '');
    const newLog = db.prepare('SELECT * FROM daily_logs WHERE id = ?').get(id);
    res.json(newLog);
  });

  app.get('/api/documents', (req, res) => {
    const docs = db.prepare('SELECT * FROM documents ORDER BY date DESC').all();
    res.json(docs);
  });

  app.post('/api/documents', upload.single('file'), (req, res) => {
    const { folder, author, version } = req.body;
    const file = req.file;
    
    if (!file) {
      return res.status(400).json({ success: false, message: 'Nenhum arquivo enviado' });
    }

    const id = 'D-' + Date.now();
    const name = file.originalname;
    const type = file.originalname.split('.').pop()?.toLowerCase() || 'unknown';
    const size = (file.size / (1024 * 1024)).toFixed(2) + ' MB';
    const date = new Date().toISOString().split('T')[0];
    const file_url = '/uploads/' + file.filename;

    const insert = db.prepare('INSERT INTO documents (id, name, type, size, date, author, version, folder, file_url) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)');
    insert.run(id, name, type, size, date, author, version || 'v1.0', folder, file_url);
    
    const newDoc = db.prepare('SELECT * FROM documents WHERE id = ?').get(id);
    res.json({ success: true, document: newDoc });
  });

  // Socket.IO
  io.on('connection', (socket) => {
    console.log('A user connected');
    socket.on('disconnect', () => {
      console.log('User disconnected');
    });
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (req, res) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  }

  httpServer.listen(PORT, '0.0.0.0', () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
