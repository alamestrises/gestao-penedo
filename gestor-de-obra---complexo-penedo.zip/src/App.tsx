/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { AuthProvider } from './context/AuthContext';
import { Layout } from './components/Layout';
import { Dashboard } from './components/Dashboard';
import { DiarioObra } from './components/DiarioObra';
import { Financeiro } from './components/Financeiro';
import { Cronograma } from './components/Cronograma';
import { GED } from './components/GED';
import { Users } from './components/Users';

function AppContent() {
  const [activeTab, setActiveTab] = useState('dashboard');

  const renderContent = () => {
    switch (activeTab) {
      case 'dashboard': return <Dashboard />;
      case 'diario': return <DiarioObra />;
      case 'financeiro': return <Financeiro />;
      case 'cronograma': return <Cronograma />;
      case 'ged': return <GED />;
      case 'users': return <Users />;
      default: return <Dashboard />;
    }
  };

  return (
    <Layout activeTab={activeTab} setActiveTab={setActiveTab}>
      {renderContent()}
    </Layout>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <AppContent />
    </AuthProvider>
  );
}
