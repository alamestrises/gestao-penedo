import React, { useState, useEffect, useRef } from 'react';
import { useAuth } from '../context/AuthContext';
import { DailyLog } from '../types';
import { Plus, Image as ImageIcon, Users, Cloud, MapPin, Calendar as CalendarIcon, BookOpen, X, Upload } from 'lucide-react';

export const DiarioObra: React.FC = () => {
  const { user } = useAuth();
  const [logs, setLogs] = useState<DailyLog[]>([]);
  const [isAdding, setIsAdding] = useState(false);
  const [isUploading, setIsUploading] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const [formData, setFormData] = useState({
    date: new Date().toISOString().split('T')[0],
    weather_condition: 'Ensolarado',
    workers_count: 15,
    description: '',
    media_urls: ''
  });

  const fetchLogs = () => {
    fetch('/api/logs').then(res => res.json()).then(setLogs);
  };

  useEffect(() => {
    fetchLogs();
  }, []);

  const handleUploadClick = () => {
    fileInputRef.current?.click();
  };

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const uploadData = new FormData();
    uploadData.append('file', file);
    uploadData.append('folder', 'DiarioObra');
    uploadData.append('uploaded_by', user?.id || '');

    setIsUploading(true);
    try {
      const res = await fetch('/api/documents', {
        method: 'POST',
        body: uploadData
      });
      if (res.ok) {
        const data = await res.json();
        setFormData(prev => ({
          ...prev,
          media_urls: prev.media_urls ? `${prev.media_urls},${data.file_url}` : data.file_url
        }));
      }
    } catch (err) {
      console.error(err);
    } finally {
      setIsUploading(false);
      if (fileInputRef.current) {
        fileInputRef.current.value = '';
      }
    }
  };

  const removeMedia = (urlToRemove: string) => {
    setFormData(prev => ({
      ...prev,
      media_urls: prev.media_urls.split(',').filter(url => url !== urlToRemove).join(',')
    }));
  };

  const handleSubmit = async () => {
    if (!formData.description) return;
    try {
      const res = await fetch('/api/logs', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...formData,
          author_id: user?.id
        })
      });
      if (res.ok) {
        setIsAdding(false);
        setFormData({
          date: new Date().toISOString().split('T')[0],
          weather_condition: 'Ensolarado',
          workers_count: 15,
          description: '',
          media_urls: ''
        });
        fetchLogs();
      }
    } catch (e) {
      console.error(e);
    }
  };

  const canAdd = user?.role_id === 'Administrador' || user?.role_id === 'Engenheiro_Arquiteto';

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Diário de Obra Digital</h1>
          <p className="text-slate-500">Registro diário de atividades, clima e efetivo</p>
        </div>
        
        {canAdd && (
          <button 
            onClick={() => setIsAdding(true)}
            className="flex items-center gap-2 px-4 py-2 bg-orange-500 text-white rounded-xl hover:bg-orange-600 transition-colors shadow-sm shadow-orange-500/20"
          >
            <Plus className="w-5 h-5" />
            <span className="font-medium">Novo Registro</span>
          </button>
        )}
      </div>

      {isAdding && (
        <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-200 mb-6">
          <h3 className="text-lg font-bold text-slate-900 mb-4">Novo Registro Diário</h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">Data</label>
              <input 
                type="date" 
                value={formData.date}
                onChange={e => setFormData({...formData, date: e.target.value})}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-orange-500 outline-none" 
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">Clima</label>
              <select 
                value={formData.weather_condition}
                onChange={e => setFormData({...formData, weather_condition: e.target.value})}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-orange-500 outline-none"
              >
                <option>Ensolarado</option>
                <option>Nublado</option>
                <option>Chuvoso</option>
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">Efetivo (Trabalhadores)</label>
              <input 
                type="number" 
                value={formData.workers_count}
                onChange={e => setFormData({...formData, workers_count: parseInt(e.target.value) || 0})}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-orange-500 outline-none" 
              />
            </div>
          </div>
          <div className="mb-4">
            <label className="block text-sm font-medium text-slate-700 mb-1">Atividades Realizadas</label>
            <textarea 
              rows={3} 
              value={formData.description}
              onChange={e => setFormData({...formData, description: e.target.value})}
              className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-orange-500 outline-none" 
              placeholder="Descreva as atividades do dia..."
            ></textarea>
          </div>
          
          {formData.media_urls && (
            <div className="mb-4 flex flex-wrap gap-2">
              {formData.media_urls.split(',').map((url, index) => (
                <div key={index} className="relative group">
                  <img src={url} alt={`Anexo ${index + 1}`} className="w-20 h-20 object-cover rounded-lg border border-slate-200" />
                  <button 
                    onClick={() => removeMedia(url)}
                    className="absolute -top-2 -right-2 bg-red-500 text-white rounded-full p-1 opacity-0 group-hover:opacity-100 transition-opacity"
                  >
                    <X className="w-3 h-3" />
                  </button>
                </div>
              ))}
            </div>
          )}

          <div className="flex items-center gap-4">
            <input 
              type="file" 
              ref={fileInputRef} 
              onChange={handleFileChange} 
              accept="image/*"
              className="hidden" 
            />
            <button 
              onClick={handleUploadClick}
              disabled={isUploading}
              className="flex items-center gap-2 px-4 py-2 border border-slate-300 text-slate-700 rounded-xl hover:bg-slate-50 transition-colors disabled:opacity-50"
            >
              {isUploading ? <Upload className="w-5 h-5 animate-bounce" /> : <ImageIcon className="w-5 h-5" />}
              <span>{isUploading ? 'Enviando...' : 'Anexar Fotos'}</span>
            </button>
            <div className="flex-1"></div>
            <button onClick={() => setIsAdding(false)} className="px-4 py-2 text-slate-500 hover:bg-slate-100 rounded-xl transition-colors">Cancelar</button>
            <button onClick={handleSubmit} className="px-4 py-2 bg-slate-900 text-white rounded-xl hover:bg-slate-800 transition-colors">Salvar Registro</button>
          </div>
        </div>
      )}

      <div className="space-y-4">
        {logs.length === 0 && !isAdding && (
          <div className="text-center py-12 bg-white rounded-2xl border border-slate-200 border-dashed">
            <BookOpen className="w-12 h-12 text-slate-300 mx-auto mb-3" />
            <h3 className="text-lg font-medium text-slate-900">Nenhum registro encontrado</h3>
            <p className="text-slate-500">Comece adicionando o primeiro log diário da obra.</p>
          </div>
        )}
        
        {logs.map(log => (
          <div key={log.id} className="bg-white p-6 rounded-2xl shadow-sm border border-slate-200">
            <div className="flex items-start justify-between mb-4 border-b border-slate-100 pb-4">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 bg-orange-100 text-orange-600 rounded-xl flex items-center justify-center font-bold text-xl">
                  {new Date(log.date).getDate() + 1}
                </div>
                <div>
                  <h3 className="text-lg font-bold text-slate-900">Relatório Diário</h3>
                  <p className="text-sm text-slate-500 flex items-center gap-2">
                    <CalendarIcon className="w-4 h-4" /> {new Date(log.date).toLocaleDateString('pt-BR')}
                  </p>
                </div>
              </div>
              <div className="flex items-center gap-4 text-sm text-slate-600">
                <div className="flex items-center gap-1 bg-slate-50 px-3 py-1.5 rounded-lg border border-slate-100">
                  <Cloud className="w-4 h-4 text-slate-400" /> {log.weather_condition}
                </div>
                <div className="flex items-center gap-1 bg-slate-50 px-3 py-1.5 rounded-lg border border-slate-100">
                  <Users className="w-4 h-4 text-slate-400" /> {log.workers_count} operários
                </div>
              </div>
            </div>
            
            <div className="mb-6">
              <h4 className="font-medium text-slate-900 mb-2">Atividades Realizadas:</h4>
              <p className="text-slate-600 whitespace-pre-wrap">{log.description}</p>
            </div>

            {log.media_urls && (
              <div className="flex flex-wrap gap-3 mt-4 pt-4 border-t border-slate-100">
                {log.media_urls.split(',').map((url, index) => (
                  <a key={index} href={url} target="_blank" rel="noopener noreferrer">
                    <img src={url} alt={`Anexo ${index + 1}`} className="w-24 h-24 object-cover rounded-xl border border-slate-200 hover:opacity-80 transition-opacity" />
                  </a>
                ))}
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
};


