import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { ConstructionPhase, Task } from '../types';
import { Calendar, Clock, AlertCircle, CheckCircle2, MoreHorizontal, Plus, X, Filter } from 'lucide-react';
import { format, differenceInDays, parseISO, isWithinInterval } from 'date-fns';
import { ptBR } from 'date-fns/locale';

export const Cronograma: React.FC = () => {
  const { user } = useAuth();
  const [phases, setPhases] = useState<ConstructionPhase[]>([]);
  const [tasks, setTasks] = useState<Task[]>([]);
  const [isAddingPhase, setIsAddingPhase] = useState(false);
  const [isFilterOpen, setIsFilterOpen] = useState(false);
  const [filterStartDate, setFilterStartDate] = useState('');
  const [filterEndDate, setFilterEndDate] = useState('');
  const [formData, setFormData] = useState({
    title: '',
    start_date: new Date().toISOString().split('T')[0],
    end_date: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
    status: 'Not Started',
    progress_percentage: 0,
    budget_allocated: 0
  });

  const fetchPhases = () => {
    fetch('/api/phases').then(res => res.json()).then(setPhases);
    fetch('/api/tasks').then(res => res.json()).then(setTasks);
  };

  useEffect(() => {
    fetchPhases();
  }, []);

  const handleAddPhase = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.title) return;
    try {
      const res = await fetch('/api/phases', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(formData)
      });
      if (res.ok) {
        setIsAddingPhase(false);
        setFormData({
          title: '',
          start_date: new Date().toISOString().split('T')[0],
          end_date: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
          status: 'Not Started',
          progress_percentage: 0,
          budget_allocated: 0
        });
        fetchPhases();
      }
    } catch (e) {
      console.error(e);
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'Feito': return 'bg-emerald-100 text-emerald-700 border-emerald-200';
      case 'Fazendo': return 'bg-blue-100 text-blue-700 border-blue-200';
      default: return 'bg-slate-100 text-slate-700 border-slate-200';
    }
  };

  const getPriorityIcon = (priority: string) => {
    switch (priority) {
      case 'Critical': return <AlertCircle className="w-4 h-4 text-red-500" />;
      case 'High': return <AlertCircle className="w-4 h-4 text-orange-500" />;
      default: return null;
    }
  };

  const filteredPhases = phases.filter(phase => {
    if (!filterStartDate && !filterEndDate) return true;
    
    const phaseStart = parseISO(phase.start_date);
    const phaseEnd = parseISO(phase.end_date);
    
    if (filterStartDate && filterEndDate) {
      const filterStart = parseISO(filterStartDate);
      const filterEnd = parseISO(filterEndDate);
      // Check if phase overlaps with filter range
      return phaseStart <= filterEnd && phaseEnd >= filterStart;
    } else if (filterStartDate) {
      return phaseEnd >= parseISO(filterStartDate);
    } else if (filterEndDate) {
      return phaseStart <= parseISO(filterEndDate);
    }
    return true;
  });

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Cronograma (Gantt) Híbrido</h1>
          <p className="text-slate-500">Gestão de fases, dependências e tarefas</p>
        </div>
        
        <div className="flex items-center gap-2 relative">
          <button 
            onClick={() => setIsFilterOpen(!isFilterOpen)}
            className={`flex items-center gap-2 px-4 py-2 border rounded-xl transition-colors shadow-sm font-medium ${
              filterStartDate || filterEndDate 
                ? 'bg-blue-50 border-blue-200 text-blue-700' 
                : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-50'
            }`}
          >
            <Filter className="w-4 h-4" />
            Filtros {(filterStartDate || filterEndDate) && '(Ativo)'}
          </button>
          
          {isFilterOpen && (
            <div className="absolute top-full right-0 mt-2 w-72 bg-white rounded-xl shadow-lg border border-slate-200 p-4 z-10">
              <div className="flex justify-between items-center mb-4">
                <h3 className="font-bold text-slate-900">Filtrar por Data</h3>
                <button onClick={() => setIsFilterOpen(false)} className="text-slate-400 hover:text-slate-600">
                  <X className="w-4 h-4" />
                </button>
              </div>
              <div className="space-y-3">
                <div>
                  <label className="block text-xs font-medium text-slate-700 mb-1">Data Inicial</label>
                  <input 
                    type="date" 
                    value={filterStartDate}
                    onChange={(e) => setFilterStartDate(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 outline-none"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-700 mb-1">Data Final</label>
                  <input 
                    type="date" 
                    value={filterEndDate}
                    onChange={(e) => setFilterEndDate(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 outline-none"
                  />
                </div>
                <div className="pt-2 flex justify-end">
                  <button 
                    onClick={() => {
                      setFilterStartDate('');
                      setFilterEndDate('');
                    }}
                    className="text-xs text-slate-500 hover:text-slate-700 font-medium"
                  >
                    Limpar Filtros
                  </button>
                </div>
              </div>
            </div>
          )}

          {user?.role_id === 'Administrador' && (
            <button 
              onClick={() => setIsAddingPhase(true)}
              className="flex items-center gap-2 px-4 py-2 bg-orange-500 text-white rounded-xl hover:bg-orange-600 transition-colors shadow-sm shadow-orange-500/20 font-medium"
            >
              <Plus className="w-5 h-5" />
              Nova Fase
            </button>
          )}
        </div>
      </div>

      {isAddingPhase && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl shadow-xl w-full max-w-md overflow-hidden">
            <div className="flex items-center justify-between p-4 border-b border-slate-100">
              <h3 className="text-lg font-bold text-slate-900">Nova Fase</h3>
              <button onClick={() => setIsAddingPhase(false)} className="text-slate-400 hover:text-slate-600">
                <X className="w-5 h-5" />
              </button>
            </div>
            <form onSubmit={handleAddPhase} className="p-4 space-y-4">
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">Título da Fase</label>
                <input 
                  type="text" 
                  required
                  value={formData.title}
                  onChange={e => setFormData({...formData, title: e.target.value})}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-orange-500 outline-none" 
                  placeholder="Ex: Fundações"
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">Data Início</label>
                  <input 
                    type="date" 
                    required
                    value={formData.start_date}
                    onChange={e => setFormData({...formData, start_date: e.target.value})}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-orange-500 outline-none" 
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">Data Fim</label>
                  <input 
                    type="date" 
                    required
                    value={formData.end_date}
                    onChange={e => setFormData({...formData, end_date: e.target.value})}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-orange-500 outline-none" 
                  />
                </div>
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">Orçamento Previsto (R$)</label>
                <input 
                  type="number" 
                  required
                  min="0"
                  step="0.01"
                  value={formData.budget_allocated || ''}
                  onChange={e => setFormData({...formData, budget_allocated: parseFloat(e.target.value) || 0})}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-orange-500 outline-none" 
                />
              </div>
              <div className="flex items-center justify-end gap-3 pt-4 border-t border-slate-100">
                <button type="button" onClick={() => setIsAddingPhase(false)} className="px-4 py-2 text-slate-600 hover:bg-slate-100 rounded-xl transition-colors font-medium">Cancelar</button>
                <button type="submit" className="px-4 py-2 bg-slate-900 text-white rounded-xl hover:bg-slate-800 transition-colors font-medium">Salvar Fase</button>
              </div>
            </form>
          </div>
        </div>
      )}

      <div className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-slate-50 border-b border-slate-200 text-sm font-medium text-slate-500">
                <th className="p-4 w-1/3">Fase / Tarefa</th>
                <th className="p-4 w-1/6">Início</th>
                <th className="p-4 w-1/6">Fim</th>
                <th className="p-4 w-1/6">Progresso</th>
                <th className="p-4 w-1/6">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredPhases.map(phase => {
                const phaseTasks = tasks.filter(t => t.phase_id === phase.id);
                return (
                  <React.Fragment key={phase.id}>
                    <tr className="hover:bg-slate-50/50 transition-colors group">
                      <td className="p-4">
                        <div className="flex items-center gap-3">
                          <div className="w-8 h-8 rounded-lg bg-orange-100 text-orange-600 flex items-center justify-center font-bold text-xs">
                            {phase.id}
                          </div>
                          <div>
                            <p className="font-bold text-slate-900">{phase.title}</p>
                            <p className="text-xs text-slate-500">{phaseTasks.length} tarefas</p>
                          </div>
                        </div>
                      </td>
                      <td className="p-4 text-sm text-slate-600">
                        {format(parseISO(phase.start_date), "dd MMM yy", { locale: ptBR })}
                      </td>
                      <td className="p-4 text-sm text-slate-600">
                        {format(parseISO(phase.end_date), "dd MMM yy", { locale: ptBR })}
                      </td>
                      <td className="p-4">
                        <div className="flex items-center gap-2">
                          <div className="w-full bg-slate-100 rounded-full h-2 max-w-[100px]">
                            <div 
                              className="bg-blue-600 h-2 rounded-full" 
                              style={{ width: `${phase.progress_percentage}%` }}
                            ></div>
                          </div>
                          <span className="text-xs font-medium text-slate-600">{phase.progress_percentage}%</span>
                        </div>
                      </td>
                      <td className="p-4">
                        <span className={`px-3 py-1 rounded-full text-xs font-medium border ${
                          phase.progress_percentage === 100 ? 'bg-emerald-100 text-emerald-700 border-emerald-200' :
                          phase.progress_percentage > 0 ? 'bg-blue-100 text-blue-700 border-blue-200' :
                          'bg-slate-100 text-slate-700 border-slate-200'
                        }`}>
                          {phase.progress_percentage === 100 ? 'Concluído' : phase.progress_percentage > 0 ? 'Em Andamento' : 'Não Iniciado'}
                        </span>
                      </td>
                    </tr>
                    {phaseTasks.map(task => (
                      <tr key={task.id} className="bg-slate-50/30 hover:bg-slate-50 transition-colors">
                        <td className="p-4 pl-14">
                          <div className="flex items-center gap-2">
                            {getPriorityIcon(task.priority)}
                            <p className="text-sm font-medium text-slate-700">{task.description}</p>
                          </div>
                        </td>
                        <td colSpan={2} className="p-4 text-sm text-slate-500">
                          <div className="flex items-center gap-1">
                            <Clock className="w-3 h-3" />
                            Vence em {format(parseISO(task.due_date), "dd MMM", { locale: ptBR })}
                          </div>
                        </td>
                        <td className="p-4 text-sm text-slate-500">
                          {task.assigned_to.replace('_', ' ')}
                        </td>
                        <td className="p-4">
                          <span className={`px-2 py-1 rounded-md text-xs font-medium border ${getStatusColor(task.status)}`}>
                            {task.status}
                          </span>
                        </td>
                      </tr>
                    ))}
                  </React.Fragment>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
