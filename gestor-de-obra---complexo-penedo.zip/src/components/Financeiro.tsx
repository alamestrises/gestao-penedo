import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { FinancialRecord, ConstructionPhase } from '../types';
import { DollarSign, TrendingUp, TrendingDown, AlertTriangle, FileText, Plus, X } from 'lucide-react';
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip as RechartsTooltip, Legend } from 'recharts';

export const Financeiro: React.FC = () => {
  const { user } = useAuth();
  const [records, setRecords] = useState<FinancialRecord[]>([]);
  const [phases, setPhases] = useState<ConstructionPhase[]>([]);
  const [isAdding, setIsAdding] = useState(false);
  const [formData, setFormData] = useState({
    category: 'Geral',
    amount: 0,
    type_in_out: 'OUT' as 'IN' | 'OUT',
    approval_status: 'Pending' as 'Pending' | 'Approved' | 'Rejected',
    date: new Date().toISOString().split('T')[0],
    description: ''
  });

  const fetchRecords = () => {
    fetch('/api/financial').then(res => res.json()).then(setRecords);
    fetch('/api/phases').then(res => res.json()).then(setPhases);
  };

  useEffect(() => {
    fetchRecords();
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.description || formData.amount <= 0) return;
    try {
      const res = await fetch('/api/financial', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(formData)
      });
      if (res.ok) {
        setIsAdding(false);
        setFormData({
          category: 'Geral',
          amount: 0,
          type_in_out: 'OUT',
          approval_status: 'Pending',
          date: new Date().toISOString().split('T')[0],
          description: ''
        });
        fetchRecords();
      }
    } catch (e) {
      console.error(e);
    }
  };

  const totalBudget = phases.reduce((acc, p) => acc + p.budget_allocated, 0);
  const totalSpent = phases.reduce((acc, p) => acc + p.budget_spent, 0);
  const remainingBudget = totalBudget - totalSpent;

  const pieData = phases.map(p => ({
    name: p.title.substring(0, 15),
    value: p.budget_spent
  })).filter(d => d.value > 0);

  const COLORS = ['#3b82f6', '#f97316', '#10b981', '#8b5cf6', '#ef4444', '#f59e0b', '#06b6d4', '#ec4899'];

  const isOverBudget = totalSpent > totalBudget;

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Gestão Financeira e Suprimentos</h1>
          <p className="text-slate-500">Controle de CAPEX, fluxo de caixa e cotações</p>
        </div>
        
        {user?.role_id === 'Administrador' && (
          <button 
            onClick={() => setIsAdding(true)}
            className="flex items-center gap-2 px-4 py-2 bg-slate-900 text-white rounded-xl hover:bg-slate-800 transition-colors shadow-sm"
          >
            <Plus className="w-5 h-5" />
            <span className="font-medium">Nova Despesa</span>
          </button>
        )}
      </div>

      {isAdding && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl shadow-xl w-full max-w-md overflow-hidden">
            <div className="flex items-center justify-between p-4 border-b border-slate-100">
              <h3 className="text-lg font-bold text-slate-900">Nova Despesa</h3>
              <button onClick={() => setIsAdding(false)} className="text-slate-400 hover:text-slate-600">
                <X className="w-5 h-5" />
              </button>
            </div>
            <form onSubmit={handleSubmit} className="p-4 space-y-4">
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">Descrição</label>
                <input 
                  type="text" 
                  required
                  value={formData.description}
                  onChange={e => setFormData({...formData, description: e.target.value})}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-orange-500 outline-none" 
                  placeholder="Ex: Concreto Usinado"
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">Valor (R$)</label>
                  <input 
                    type="number" 
                    required
                    min="0"
                    step="0.01"
                    value={formData.amount || ''}
                    onChange={e => setFormData({...formData, amount: parseFloat(e.target.value) || 0})}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-orange-500 outline-none" 
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">Data</label>
                  <input 
                    type="date" 
                    required
                    value={formData.date}
                    onChange={e => setFormData({...formData, date: e.target.value})}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-orange-500 outline-none" 
                  />
                </div>
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">Fase / Categoria</label>
                <select 
                  value={formData.category}
                  onChange={e => setFormData({...formData, category: e.target.value})}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-orange-500 outline-none"
                >
                  <option value="Geral">Geral</option>
                  {phases.map(p => (
                    <option key={p.id} value={p.id}>{p.id} - {p.title}</option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">Status de Pagamento</label>
                <select 
                  value={formData.approval_status}
                  onChange={e => setFormData({...formData, approval_status: e.target.value as any})}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-orange-500 outline-none"
                >
                  <option value="Pending">Pendente</option>
                  <option value="Approved">Pago</option>
                </select>
              </div>
              <div className="flex items-center justify-end gap-3 pt-4 border-t border-slate-100">
                <button type="button" onClick={() => setIsAdding(false)} className="px-4 py-2 text-slate-600 hover:bg-slate-100 rounded-xl transition-colors font-medium">Cancelar</button>
                <button type="submit" className="px-4 py-2 bg-slate-900 text-white rounded-xl hover:bg-slate-800 transition-colors font-medium">Salvar Despesa</button>
              </div>
            </form>
          </div>
        </div>
      )}

      {isOverBudget && (
        <div className="bg-red-50 border border-red-200 p-4 rounded-xl flex items-start gap-3">
          <AlertTriangle className="w-6 h-6 text-red-600 shrink-0 mt-0.5" />
          <div>
            <h3 className="text-red-800 font-bold">Alerta de Estouro de Orçamento</h3>
            <p className="text-red-600 text-sm mt-1">
              Os gastos totais (R$ {(totalSpent/1000000).toFixed(2)}M) ultrapassaram o orçamento previsto (R$ {(totalBudget/1000000).toFixed(2)}M).
              Revise as rubricas imediatamente.
            </p>
          </div>
        </div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-200">
          <div className="flex items-center justify-between mb-2">
            <h3 className="text-slate-500 font-medium">Orçamento Base (CAPEX)</h3>
            <DollarSign className="w-5 h-5 text-slate-400" />
          </div>
          <span className="text-3xl font-bold text-slate-900">R$ {(totalBudget/1000000).toFixed(2)}M</span>
        </div>
        <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-200">
          <div className="flex items-center justify-between mb-2">
            <h3 className="text-slate-500 font-medium">Total Realizado</h3>
            <TrendingUp className={`w-5 h-5 ${isOverBudget ? 'text-red-500' : 'text-orange-500'}`} />
          </div>
          <span className={`text-3xl font-bold ${isOverBudget ? 'text-red-600' : 'text-slate-900'}`}>
            R$ {(totalSpent/1000000).toFixed(2)}M
          </span>
        </div>
        <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-200">
          <div className="flex items-center justify-between mb-2">
            <h3 className="text-slate-500 font-medium">Saldo Disponível</h3>
            <TrendingDown className="w-5 h-5 text-emerald-500" />
          </div>
          <span className={`text-3xl font-bold ${remainingBudget < 0 ? 'text-red-600' : 'text-emerald-600'}`}>
            R$ {(remainingBudget/1000000).toFixed(2)}M
          </span>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-200">
          <h3 className="text-lg font-bold text-slate-900 mb-6">Distribuição de Custos por Fase</h3>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={pieData}
                  cx="50%"
                  cy="50%"
                  innerRadius={60}
                  outerRadius={80}
                  paddingAngle={5}
                  dataKey="value"
                >
                  {pieData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <RechartsTooltip formatter={(value: number) => `R$ ${(value/1000).toFixed(1)}k`} />
                <Legend />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-200 flex flex-col">
          <div className="flex items-center justify-between mb-6">
            <h3 className="text-lg font-bold text-slate-900">Últimos Lançamentos</h3>
            <button className="text-sm text-blue-600 hover:text-blue-700 font-medium">Ver todos</button>
          </div>
          <div className="flex-1 overflow-y-auto pr-2 space-y-3">
            {records.length === 0 ? (
              <p className="text-slate-500 text-center py-4">Nenhum lançamento encontrado.</p>
            ) : (
              records.map((rec) => (
                <div key={rec.id} className="flex items-center justify-between p-3 rounded-xl border border-slate-100 hover:bg-slate-50 transition-colors">
                  <div className="flex items-center gap-3">
                    <div className="p-2 bg-slate-100 text-slate-500 rounded-lg">
                      <FileText className="w-4 h-4" />
                    </div>
                    <div>
                      <p className="font-medium text-slate-900 text-sm">{rec.description || rec.category}</p>
                      <p className="text-xs text-slate-500">{new Date(rec.date).toLocaleDateString('pt-BR')}</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="font-bold text-slate-900 text-sm">R$ {(rec.amount/1000).toFixed(1)}k</p>
                    <span className={`text-xs font-medium ${rec.approval_status === 'Approved' ? 'text-emerald-600' : 'text-orange-600'}`}>
                      {rec.approval_status === 'Approved' ? 'Pago' : 'Pendente'}
                    </span>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
