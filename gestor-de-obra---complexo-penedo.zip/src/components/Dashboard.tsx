import React, { useEffect, useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { ConstructionPhase, Task } from '../types';
import { io } from 'socket.io-client';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  Legend, 
  ResponsiveContainer,
  LineChart,
  Line
} from 'recharts';
import { AlertCircle, CheckCircle2, Clock, CloudRain, Sun, Thermometer, Wind, DollarSign } from 'lucide-react';

const socket = io(import.meta.env.VITE_APP_URL || 'http://localhost:3000');

export const Dashboard: React.FC = () => {
  const { user } = useAuth();
  const [phases, setPhases] = useState<ConstructionPhase[]>([]);
  const [tasks, setTasks] = useState<Task[]>([]);
  const [weather, setWeather] = useState({ temp: 24, condition: 'Ensolarado', rainProb: 10, wind: 12 });

  useEffect(() => {
    fetch('/api/phases').then(res => res.json()).then(setPhases);
    fetch('/api/tasks').then(res => res.json()).then(setTasks);

    socket.on('task_update', (updatedTask: Task) => {
      setTasks(prev => prev.map(t => t.id === updatedTask.id ? updatedTask : t));
    });

    return () => {
      socket.off('task_update');
    };
  }, []);

  const totalBudget = phases.reduce((acc, p) => acc + p.budget_allocated, 0);
  const totalSpent = phases.reduce((acc, p) => acc + p.budget_spent, 0);
  const overallProgress = phases.length > 0 
    ? Math.round(phases.reduce((acc, p) => acc + p.progress_percentage, 0) / phases.length)
    : 0;

  const chartData = phases.map(p => ({
    name: p.title.substring(0, 15) + '...',
    Orçado: p.budget_allocated,
    Realizado: p.budget_spent,
    Progresso: p.progress_percentage
  }));

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Dashboard Interativo</h1>
          <p className="text-slate-500">Visão geral da obra Complexo Penedo</p>
        </div>
        
        {/* Weather Widget */}
        <div className="bg-white rounded-2xl p-4 shadow-sm border border-slate-200 flex items-center gap-6">
          <div className="flex items-center gap-3">
            <div className="p-3 bg-orange-100 text-orange-600 rounded-xl">
              {weather.condition === 'Ensolarado' ? <Sun className="w-6 h-6" /> : <CloudRain className="w-6 h-6" />}
            </div>
            <div>
              <p className="text-sm text-slate-500 font-medium">Penedo, RJ</p>
              <p className="text-xl font-bold text-slate-900">{weather.temp}°C</p>
            </div>
          </div>
          <div className="hidden sm:flex items-center gap-4 border-l border-slate-100 pl-6">
            <div className="flex flex-col gap-1">
              <div className="flex items-center gap-1 text-xs text-slate-500">
                <CloudRain className="w-3 h-3" /> Prob. Chuva
              </div>
              <span className="font-semibold text-slate-700">{weather.rainProb}%</span>
            </div>
            <div className="flex flex-col gap-1">
              <div className="flex items-center gap-1 text-xs text-slate-500">
                <Wind className="w-3 h-3" /> Vento
              </div>
              <span className="font-semibold text-slate-700">{weather.wind} km/h</span>
            </div>
          </div>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-200">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-slate-500 font-medium">Progresso Geral</h3>
            <div className="p-2 bg-blue-50 text-blue-600 rounded-lg">
              <CheckCircle2 className="w-5 h-5" />
            </div>
          </div>
          <div className="flex items-end gap-2">
            <span className="text-3xl font-bold text-slate-900">{overallProgress}%</span>
          </div>
          <div className="w-full bg-slate-100 rounded-full h-2 mt-4">
            <div className="bg-blue-600 h-2 rounded-full" style={{ width: `${overallProgress}%` }}></div>
          </div>
        </div>

        {user?.role_id === 'Administrador' && (
          <>
            <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-200">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-slate-500 font-medium">Orçamento Total</h3>
                <div className="p-2 bg-emerald-50 text-emerald-600 rounded-lg">
                  <DollarSign className="w-5 h-5" />
                </div>
              </div>
              <div className="flex items-end gap-2">
                <span className="text-3xl font-bold text-slate-900">
                  R$ {(totalBudget / 1000000).toFixed(1)}M
                </span>
              </div>
            </div>

            <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-200">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-slate-500 font-medium">Custo Realizado</h3>
                <div className="p-2 bg-orange-50 text-orange-600 rounded-lg">
                  <DollarSign className="w-5 h-5" />
                </div>
              </div>
              <div className="flex items-end gap-2">
                <span className="text-3xl font-bold text-slate-900">
                  R$ {(totalSpent / 1000000).toFixed(2)}M
                </span>
              </div>
              <div className="w-full bg-slate-100 rounded-full h-2 mt-4">
                <div 
                  className={`h-2 rounded-full ${totalSpent > totalBudget ? 'bg-red-500' : 'bg-orange-500'}`} 
                  style={{ width: `${Math.min((totalSpent / totalBudget) * 100, 100)}%` }}
                ></div>
              </div>
            </div>
          </>
        )}

        <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-200">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-slate-500 font-medium">Tarefas Ativas</h3>
            <div className="p-2 bg-purple-50 text-purple-600 rounded-lg">
              <Clock className="w-5 h-5" />
            </div>
          </div>
          <div className="flex items-end gap-2">
            <span className="text-3xl font-bold text-slate-900">
              {tasks.filter(t => t.status !== 'Feito').length}
            </span>
            <span className="text-sm text-slate-500 mb-1">pendentes</span>
          </div>
        </div>
      </div>

      {/* Charts & Lists */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Chart */}
        <div className="lg:col-span-2 bg-white p-6 rounded-2xl shadow-sm border border-slate-200">
          <h3 className="text-lg font-bold text-slate-900 mb-6">Avanço Físico-Financeiro</h3>
          <div className="h-80">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={chartData} margin={{ top: 20, right: 30, left: 20, bottom: 5 }}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e2e8f0" />
                <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{ fill: '#64748b', fontSize: 12 }} />
                <YAxis yAxisId="left" orientation="left" stroke="#64748b" axisLine={false} tickLine={false} tickFormatter={(value) => `R$ ${value/1000}k`} />
                <YAxis yAxisId="right" orientation="right" stroke="#3b82f6" axisLine={false} tickLine={false} tickFormatter={(value) => `${value}%`} />
                <Tooltip 
                  cursor={{ fill: '#f1f5f9' }}
                  contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)' }}
                />
                <Legend iconType="circle" wrapperStyle={{ paddingTop: '20px' }} />
                <Bar yAxisId="left" dataKey="Orçado" fill="#e2e8f0" radius={[4, 4, 0, 0]} />
                <Bar yAxisId="left" dataKey="Realizado" fill="#f97316" radius={[4, 4, 0, 0]} />
                <Line yAxisId="right" type="monotone" dataKey="Progresso" stroke="#3b82f6" strokeWidth={3} dot={{ r: 4, fill: '#3b82f6', strokeWidth: 2, stroke: '#fff' }} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Recent Tasks / Feed */}
        <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-200 flex flex-col">
          <h3 className="text-lg font-bold text-slate-900 mb-6">Tarefas Recentes</h3>
          <div className="flex-1 overflow-y-auto pr-2 space-y-4">
            {tasks.slice(0, 5).map(task => (
              <div key={task.id} className="p-4 rounded-xl border border-slate-100 bg-slate-50/50 hover:bg-slate-50 transition-colors">
                <div className="flex items-start justify-between gap-2 mb-2">
                  <h4 className="font-medium text-slate-900 text-sm">{task.description}</h4>
                  <span className={`px-2 py-1 rounded-md text-xs font-medium ${
                    task.priority === 'Critical' ? 'bg-red-100 text-red-700' :
                    task.priority === 'High' ? 'bg-orange-100 text-orange-700' :
                    'bg-blue-100 text-blue-700'
                  }`}>
                    {task.priority}
                  </span>
                </div>
                <div className="flex items-center justify-between text-xs text-slate-500">
                  <span className="flex items-center gap-1">
                    <Clock className="w-3 h-3" /> {new Date(task.due_date).toLocaleDateString('pt-BR')}
                  </span>
                  <span className={`font-medium ${
                    task.status === 'Feito' ? 'text-emerald-600' :
                    task.status === 'Fazendo' ? 'text-blue-600' :
                    'text-slate-500'
                  }`}>
                    {task.status}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};


