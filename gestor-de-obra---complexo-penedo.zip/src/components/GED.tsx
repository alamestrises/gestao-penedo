import React, { useState, useEffect, useRef } from 'react';
import { useAuth } from '../context/AuthContext';
import { Document } from '../types';
import { Folder, FileText, Download, Upload, Search, Filter, MoreVertical, FileArchive, FileImage, FileCode, Trash2 } from 'lucide-react';

export const GED: React.FC = () => {
  const { user } = useAuth();
  const [activeTab, setActiveTab] = useState('Projetos');
  const [documents, setDocuments] = useState<Document[]>([]);
  const [isUploading, setIsUploading] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const fetchDocuments = () => {
    fetch('/api/documents').then(res => res.json()).then(setDocuments);
  };

  useEffect(() => {
    fetchDocuments();
  }, []);

  const handleUploadClick = () => {
    fileInputRef.current?.click();
  };

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const formData = new FormData();
    formData.append('file', file);
    formData.append('folder', activeTab);
    formData.append('uploaded_by', user?.id || '');

    setIsUploading(true);
    try {
      const res = await fetch('/api/documents', {
        method: 'POST',
        body: formData
      });
      if (res.ok) {
        fetchDocuments();
      }
    } catch (err) {
      console.error(err);
    } finally {
      setIsUploading(false);
      if (fileInputRef.current) {
        fileInputRef.current.value = '';
      }
    }
  };

  const folders = [
    { id: 'Projetos', label: 'Projetos Técnicos' },
    { id: 'Legalizacao', label: 'Legalização e Alvarás' },
    { id: 'Contratos', label: 'Contratos e Fornecedores' },
    { id: 'Manuais', label: 'Manuais e Garantias' },
  ];

  const filteredFiles = documents.filter(f => f.folder === activeTab);

  const getFileIcon = (type: string) => {
    if (type.includes('pdf')) return <FileText className="w-8 h-8 text-red-500" />;
    if (type.includes('image')) return <FileImage className="w-8 h-8 text-blue-500" />;
    if (type.includes('zip') || type.includes('rar')) return <FileArchive className="w-8 h-8 text-amber-500" />;
    if (type.includes('dwg') || type.includes('dxf')) return <FileCode className="w-8 h-8 text-blue-500" />;
    return <FileText className="w-8 h-8 text-slate-500" />;
  };

  const formatFileSize = (bytes: number) => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Gestão Eletrônica de Documentos (GED)</h1>
          <p className="text-slate-500">Armazenamento, versionamento e consulta de projetos</p>
        </div>
        
        {user?.role_id === 'Administrador' || user?.role_id === 'Engenheiro_Arquiteto' ? (
          <div className="flex items-center gap-3">
            <input 
              type="file" 
              ref={fileInputRef} 
              onChange={handleFileChange} 
              className="hidden" 
            />
            <button 
              onClick={handleUploadClick}
              disabled={isUploading}
              className="flex items-center gap-2 px-4 py-2 bg-slate-900 text-white rounded-xl hover:bg-slate-800 transition-colors shadow-sm disabled:opacity-50"
            >
              <Upload className="w-5 h-5" />
              <span className="font-medium">{isUploading ? 'Enviando...' : 'Fazer Upload'}</span>
            </button>
          </div>
        ) : null}
      </div>

      <div className="flex flex-col lg:flex-row gap-6">
        {/* Sidebar Folders */}
        <div className="w-full lg:w-64 shrink-0 space-y-2">
          {folders.map(folder => {
            const count = documents.filter(d => d.folder === folder.id).length;
            return (
              <button
                key={folder.id}
                onClick={() => setActiveTab(folder.id)}
                className={`w-full flex items-center justify-between p-3 rounded-xl transition-all ${
                  activeTab === folder.id 
                    ? 'bg-blue-50 border-blue-200 text-blue-700 border' 
                    : 'bg-white border-slate-200 text-slate-600 hover:bg-slate-50 border'
                }`}
              >
                <div className="flex items-center gap-3">
                  <Folder className={`w-5 h-5 ${activeTab === folder.id ? 'text-blue-500' : 'text-slate-400'}`} />
                  <span className="font-medium text-sm">{folder.label}</span>
                </div>
                <span className={`text-xs font-bold px-2 py-1 rounded-full ${
                  activeTab === folder.id ? 'bg-blue-100 text-blue-700' : 'bg-slate-100 text-slate-500'
                }`}>
                  {count}
                </span>
              </button>
            );
          })}
        </div>

        {/* Main Content */}
        <div className="flex-1 bg-white rounded-2xl shadow-sm border border-slate-200 p-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
            <h2 className="text-lg font-bold text-slate-900">{folders.find(f => f.id === activeTab)?.label}</h2>
            <div className="flex items-center gap-2">
              <div className="relative">
                <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input 
                  type="text" 
                  placeholder="Buscar arquivos..." 
                  className="pl-9 pr-4 py-2 border border-slate-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none w-full sm:w-64"
                />
              </div>
              <button className="p-2 border border-slate-300 rounded-lg text-slate-600 hover:bg-slate-50 transition-colors">
                <Filter className="w-4 h-4" />
              </button>
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b border-slate-200 text-sm font-medium text-slate-500">
                  <th className="pb-3 font-medium">Nome do Arquivo</th>
                  <th className="pb-3 font-medium">Versão</th>
                  <th className="pb-3 font-medium">Data</th>
                  <th className="pb-3 font-medium">Tamanho</th>
                  <th className="pb-3 font-medium text-right">Ações</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filteredFiles.length > 0 ? (
                  filteredFiles.map(file => (
                    <tr key={file.id} className="hover:bg-slate-50/50 transition-colors group">
                      <td className="py-4">
                        <div className="flex items-center gap-3">
                          {getFileIcon(file.file_type)}
                          <div>
                            <p className="font-medium text-slate-900 text-sm">{file.title}</p>
                            <p className="text-xs text-slate-500 uppercase">{file.file_type.split('/')[1] || file.file_type}</p>
                          </div>
                        </div>
                      </td>
                      <td className="py-4">
                        <span className="px-2 py-1 bg-slate-100 text-slate-600 rounded-md text-xs font-bold border border-slate-200">
                          {file.version}
                        </span>
                      </td>
                      <td className="py-4 text-sm text-slate-500">
                        {new Date(file.uploaded_at).toLocaleDateString('pt-BR')}
                      </td>
                      <td className="py-4 text-sm text-slate-500">
                        {formatFileSize(file.file_size)}
                      </td>
                      <td className="py-4 text-right">
                        <div className="flex items-center justify-end gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                          <a href={file.file_url} target="_blank" rel="noopener noreferrer" className="p-2 text-slate-400 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition-colors" title="Download">
                            <Download className="w-4 h-4" />
                          </a>
                          {user?.role_id === 'Administrador' && (
                            <button className="p-2 text-slate-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition-colors" title="Excluir">
                              <Trash2 className="w-4 h-4" />
                            </button>
                          )}
                        </div>
                      </td>
                    </tr>
                  ))
                ) : (
                  <tr>
                    <td colSpan={5} className="py-12 text-center text-slate-500">
                      Nenhum arquivo encontrado nesta pasta.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
};
