export type Role = 'Administrador' | 'Engenheiro_Arquiteto' | 'Inversor_Visualizador' | 'Empreiteiro_Fornecedor';

export interface User {
  id: string;
  name: string;
  email: string;
  role_id: Role;
  last_login: string;
  status: string;
}

export interface ConstructionPhase {
  id: string;
  title: string;
  start_date: string;
  end_date: string;
  progress_percentage: number;
  budget_allocated: number;
  budget_spent: number;
}

export interface Task {
  id: string;
  phase_id: string;
  description: string;
  assigned_to: Role;
  priority: 'Low' | 'Medium' | 'High' | 'Critical';
  status: 'A fazer' | 'Fazendo' | 'Feito';
  due_date: string;
}

export interface DailyLog {
  id: string;
  author_id: string;
  date: string;
  weather_condition: string;
  workers_count: number;
  description: string;
  media_urls: string;
}

export interface FinancialRecord {
  id: string;
  category: string;
  amount: number;
  type_in_out: 'IN' | 'OUT';
  receipt_url: string;
  approval_status: 'Pending' | 'Approved' | 'Rejected';
  date: string;
  description?: string;
}

export interface Document {
  id: string;
  title: string;
  file_url: string;
  file_type: string;
  file_size: number;
  folder: string;
  version: string;
  uploaded_by: string;
  uploaded_at: string;
}
